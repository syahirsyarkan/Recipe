﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace Recipe.Pages
{
    public class AddIngredientModel : PageModel
    {
        public void OnGet()
        {
            // Empty, as we only need to display the form.
        }

        public IActionResult OnPost(string ingredientName)
        {
            if (ModelState.IsValid)
            {
                // Add the ingredient to the database.
                string connectionString = @"Data Source=LAPTOP-9OJ599RJ\SQLEXPRESS01;Initial Catalog=bakery_db;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Ingredients (Name) VALUES (@Name)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", ingredientName);
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }

                // Redirect to a success page or do something else as needed.
                return RedirectToPage("/Index"); // Replace "/Index" with the desired page.
            }

            // If the model state is invalid, return to the form page to display errors.
            return Page();
        }
    }
}
