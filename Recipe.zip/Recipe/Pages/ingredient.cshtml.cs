using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Recipe.Pages
{
    public class ingredientModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
