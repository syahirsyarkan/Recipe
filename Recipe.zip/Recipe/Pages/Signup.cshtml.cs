using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace Recipe.Pages
{
    public class SignupModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
