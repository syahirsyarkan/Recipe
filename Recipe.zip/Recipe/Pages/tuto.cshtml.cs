using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Recipe.Pages
{
    public class tutoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
