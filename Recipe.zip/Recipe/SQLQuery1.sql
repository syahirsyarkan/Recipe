﻿USE bakery_db; -- Replace 'bakery_db' with your actual database name

-- Drop the column if it already exists (optional, only if the column exists)
ALTER TABLE dbo.Ingredients
DROP COLUMN Id;

-- Add the 'Id' column as an identity column
ALTER TABLE dbo.Ingredients
ADD Id INT IDENTITY(1,1) PRIMARY KEY;
